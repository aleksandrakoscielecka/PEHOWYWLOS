/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    extend: {
      colors: {
        'accent': '#cfb99d',
      },
    },
  },
  plugins: [],
}
